
from flask import Flask, request, jsonify
import json
import openai
import os
from unidecode import unidecode
from flask_cors import CORS

app = Flask(__name__)
CORS(app)



@app.route('/generate', methods=['GET'])
def generate_informations():
    try:
        # Votre logique pour générer les informations de culture générale ici
        openai.api_key = "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"

        response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Toi, tu es un professeur."},
            {"role": "user",
                "content": "Ecris 3 infomations de culture générale sur les thèmes de ton choix, essaye de donner de la culture générale amusante de temps en temps. Commence chaque nouvelle information de culture générale par un #."}
        ]   
    )

        print("---------")
        text = unidecode(response.choices[0].message.content)
        # Extraction des phrases de culture générale
        print(text)
        txt1 = text.split("#")[1] or text.split("1.")[0]
        txt2 = text.split("#")[2] or text.split("2.")[0]
        txt3 = text.split("#")[3] or text.split("3.")[0]
        

        return jsonify({'text1': txt1,'text2':txt2,'text3':txt3}) 

    
    except Exception as e:
        # Gérez les erreurs ici
        return jsonify({'error': str(e)})   

if __name__ == '__main__':
    app.run(debug=True)
